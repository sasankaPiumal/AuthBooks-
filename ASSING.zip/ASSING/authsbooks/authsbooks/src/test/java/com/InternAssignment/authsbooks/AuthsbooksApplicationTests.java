package com.InternAssignment.authsbooks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthsbooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
