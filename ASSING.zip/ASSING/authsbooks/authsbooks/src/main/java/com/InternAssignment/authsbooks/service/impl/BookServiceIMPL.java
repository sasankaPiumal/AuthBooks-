package com.InternAssignment.authsbooks.service.impl;

import com.InternAssignment.authsbooks.dto.BookDTO;
import com.InternAssignment.authsbooks.entity.Book;
import com.InternAssignment.authsbooks.repo.BookRepo;
import com.InternAssignment.authsbooks.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookServiceIMPL implements BookService {

    @Autowired
    private BookRepo bookRepo;


    @Override
    public List<BookDTO> AllBooks() {
        List<Book> getBooks = bookRepo.findAll();
        List<BookDTO> bookDTOList = new ArrayList<>();

        for (Book b : getBooks) {

            BookDTO bookDTO = new BookDTO(
                    b.getBookId(),
                    b.getBookName(),
                    b.getBookPage()
            );
            bookDTOList.add(bookDTO);

        }
        return bookDTOList;
    }
}
