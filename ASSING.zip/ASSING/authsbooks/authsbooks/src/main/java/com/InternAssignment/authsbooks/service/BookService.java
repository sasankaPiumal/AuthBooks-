package com.InternAssignment.authsbooks.service;

import com.InternAssignment.authsbooks.dto.BookDTO;

import java.util.List;

public interface BookService {

    List<BookDTO> AllBooks();
}
