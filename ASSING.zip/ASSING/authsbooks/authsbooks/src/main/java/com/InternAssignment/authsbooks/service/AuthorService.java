package com.InternAssignment.authsbooks.service;

public interface AuthorService {
}
