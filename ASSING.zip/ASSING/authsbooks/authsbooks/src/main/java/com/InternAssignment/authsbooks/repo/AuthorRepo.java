package com.InternAssignment.authsbooks.repo;

import com.InternAssignment.authsbooks.entity.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

@EnableJpaRepositories
@Repository
public interface AuthorRepo extends JpaRepository<Author,Integer> {

}
