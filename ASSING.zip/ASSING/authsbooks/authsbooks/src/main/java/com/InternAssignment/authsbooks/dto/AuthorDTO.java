package com.InternAssignment.authsbooks.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class AuthorDTO {

    private int authorId;
    private String authorName;
    private String authorEMail;
    private String authorNIC;

}
