package com.InternAssignment.authsbooks.entity;

import lombok.*;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "author")
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Author {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "author_id",length = 12)
    private int authorId;

    @Column(name = "author_name",length = 150,nullable = false)
    private String authorName;

    @Column(name = "author_email",length = 100,unique = true)
    private String authorEMail;

    @Column(name = "nic",length = 12,unique = true)
    private String authorNIC;

    //--------------------------------------------------------------------------------------------
    @ManyToMany(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
    @JoinTable(
            name = "Author_books",
            joinColumns = {@JoinColumn(name = "author_id")},
            inverseJoinColumns = {@JoinColumn(name = "book_id")}
    )
    private List<Book> books;// = new ArrayList<>();

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
