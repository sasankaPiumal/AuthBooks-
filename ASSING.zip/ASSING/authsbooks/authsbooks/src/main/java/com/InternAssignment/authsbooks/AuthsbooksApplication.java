package com.InternAssignment.authsbooks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthsbooksApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthsbooksApplication.class, args);
	}

}
