package com.InternAssignment.authsbooks.service.impl;

import com.InternAssignment.authsbooks.repo.AuthorRepo;
import com.InternAssignment.authsbooks.service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthorServiceIMPL implements AuthorService {

    @Autowired
    private AuthorRepo authorRepo;

}
